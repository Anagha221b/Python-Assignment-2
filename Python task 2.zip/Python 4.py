my_tuple = (1, 2, 3, 4)


print(len(my_tuple))


