person = {
    'name': 'John',
    'age': 25,
    'address': 'New York'
}
print("Initial dictionary:", person)

person['phone'] = '1234567890'
print("Updated dictionary:", person)
