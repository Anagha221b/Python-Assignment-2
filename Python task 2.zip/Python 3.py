my_set = {1, 2, 3, 4, 5}

my_set.add(6)

my_set.remove(3)
