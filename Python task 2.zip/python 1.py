import random
random_numbers = [random.randint(1, 100) for _ in range(5)]
print("List of 5 random numbers:", random_numbers)


new_values = [random.randint(1, 100) for _ in range(3)]
random_numbers.extend(new_values)
print("Updated list after inserting 3 new values:", random_numbers)

print("Elements in the updated list:")
for number in random_numbers:
    print(number)